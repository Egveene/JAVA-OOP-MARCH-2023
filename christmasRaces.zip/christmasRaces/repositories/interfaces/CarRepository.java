package christmasRaces.repositories.interfaces;

import christmasRaces.entities.cars.Car;

import java.util.Collection;

public class CarRepository implements  Repository<Car>{
   private Collection<Car> cars;
    private Car car;

    @Override
    public Car getByName(String name) {
        return null;
    }

    @Override
    public Collection getAll() {
        return null;
    }

    @Override
    public void add(Car car) {

    }

    @Override
    public boolean remove(Car car) {
        return false;
    }
}
