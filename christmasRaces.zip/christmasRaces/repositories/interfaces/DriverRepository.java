package christmasRaces.repositories.interfaces;

import christmasRaces.entities.drivers.Driver;

import java.util.Collection;

public class DriverRepository implements Repository<Driver> {
    private Collection<Driver> drivers;
    private Driver driver;


    @Override
    public Driver getByName(String name) {
        return null;
    }

    @Override
    public Collection<Driver> getAll() {
        return null;
    }

    @Override
    public void add(Driver driver) {

    }

    @Override
    public boolean remove(Driver driver) {
        return false;
    }
}
