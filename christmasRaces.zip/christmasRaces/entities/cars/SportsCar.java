package christmasRaces.entities.cars;

import christmasRaces.common.ExceptionMessages;

public class SportsCar extends BaseCar {
    public static final int MIN_HORSE_POWER = 250;
    public static final int MAX_HORSE_POWER = 450;

    public SportsCar(String model, int horsePower) {
        super(model, horsePower, 3000);
    }

    @Override
    public int getHorsePower() {
        if (super.getHorsePower() < MIN_HORSE_POWER && super.getHorsePower() > MAX_HORSE_POWER) {
            throw new IllegalArgumentException(ExceptionMessages.INVALID_HORSE_POWER);
        }
        return super.getHorsePower();
    }

}
