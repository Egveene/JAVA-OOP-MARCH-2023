package christmasRaces.entities.races;

import christmasRaces.repositories.interfaces.Repository;

import java.util.Collection;

public class RaceRepository implements Repository<Race>  {
  private Collection<Race> races;
  private Race race;


    @Override
    public Race getByName(String name) {
        return null;
    }

    @Override
    public Collection<Race> getAll() {
        return null;
    }

    @Override
    public void add(Race race) {

    }

    @Override
    public boolean remove(Race race) {
        return false;
    }
}
