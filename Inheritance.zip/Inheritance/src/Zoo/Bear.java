package Zoo;

public class Bear extends Mammal {

    public Bear(String name) {
        super(name);
    }
}
