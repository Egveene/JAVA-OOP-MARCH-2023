import Animals.Animal;
import Animals.Cat;
import Animals.Dog;
import Animals.Puppy;

public class Main {
    public static void main(String[] args) {

        Animal animal = new Animal();
        animal.eat();

        Dog dog = new Dog();
        dog.bark();

        dog.eat();

        Puppy puppy = new Puppy();
        puppy.weep();

        puppy.bark();

        puppy.eat();
        Cat cat = new Cat();
        cat.meow();

    }
}