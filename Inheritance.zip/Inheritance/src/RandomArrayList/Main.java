package RandomArrayList;


public class Main {
    public static void main(String[] args) {
        RandomArrayList <Integer> randomArrayList = new RandomArrayList();
          randomArrayList.add(5);
          
    }
}
