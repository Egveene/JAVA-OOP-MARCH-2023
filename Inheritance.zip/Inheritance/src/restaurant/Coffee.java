package restaurant;

import java.math.BigDecimal;

public class Coffee extends HotBeverage {
    public static final double COFFEE_MILLILITERS = 50;
    private static double caffeine;
    public static final BigDecimal COFFEE_PRICE =new BigDecimal(3.50);

    public Coffee(String name, BigDecimal price, double milliliters) {
        super(name, price, milliliters);
        this.setPrice(COFFEE_PRICE);
    }

    public static double getCaffeine() {
        return caffeine;
    }

    public static void setCaffeine(double caffeine) {
        Coffee.caffeine = caffeine;
    }
}
