package restaurant;

import java.math.BigDecimal;

public class Cake extends Dessert{
    public static final double CAKE_GRAMS = 250.0;
    public static final double CAKE_CALORIES = 1000;
    public static final BigDecimal CAKE_PRICE = new BigDecimal(5);

    public Cake(String name, BigDecimal price, double grams, double calories) {
        super(name, price, grams, calories);
        this.setGrams(CAKE_GRAMS);
        this.setCalories(CAKE_CALORIES);
        this.setPrice(CAKE_PRICE);
    }
}
