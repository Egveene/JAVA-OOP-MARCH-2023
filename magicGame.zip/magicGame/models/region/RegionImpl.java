package magicGame.models.region;

import magicGame.models.magicians.Magician;
import magicGame.models.magics.Magic;

import java.util.Collection;

public class RegionImpl implements Region{

    private Collection<Magician> magicians;
    private Magician magician;
    private Magic magic;

    @Override
    public String start(Collection<Magician> magicians) {
        return null;
    }
}
