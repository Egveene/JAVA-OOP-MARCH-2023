package aquarium.entities.aquariums;

public class FreshwaterAquarium extends BaseAquarium{
    public FreshwaterAquarium(String name) {
        super(name, 50);
    }
}
