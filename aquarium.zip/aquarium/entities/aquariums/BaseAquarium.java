package aquarium.entities.aquariums;

import aquarium.common.ConstantMessages;
import aquarium.common.ExceptionMessages;
import aquarium.entities.decorations.Decoration;
import aquarium.entities.fish.Fish;

import java.util.Collection;

public abstract class BaseAquarium implements Aquarium {

//name - String //oIf the name is null or whitespace, throw a NullPointerException with a message:
//"Aquarium name cannot be null or empty."//oAll names are unique.
//capacity -  int//oThe number of Fish аn Aquarium can have.
//decorations - Collection<Decoration>
//fish - Collection<Fish>

    private String name;
    private int capacity;
    private Collection<Decoration> decorations;
    private Collection<Fish> fish;

    protected BaseAquarium(String name, int capacity) {
        setName(name);
        this.capacity = capacity;
    }

    private void setName(String name) {
        if (name == null || name.trim().isEmpty()) {
            throw new NullPointerException(ExceptionMessages.AQUARIUM_NAME_NULL_OR_EMPTY);
        }
        this.name = name;
    }

    @Override
    public int calculateComfort() {
        int sumComfrordSDecoration = 0;
        for (Decoration decoration:
             decorations) {
           sumComfrordSDecoration += decoration.getComfort();
                    }

        return sumComfrordSDecoration;
    }

    @Override
    public String getName() {
        return this.name;
    }

    @Override
    public void addFish(Fish fish) {
        if(this.capacity < this.fish.size()){
        throw new IllegalStateException(ConstantMessages.NOT_ENOUGH_CAPACITY);
        }
        this.fish.add(fish);
    }

    @Override
    public void removeFish(Fish fish) {
     this.fish.remove(fish);
    }

    @Override
    public void addDecoration(Decoration decoration) {
    this.decorations.add(decoration);
    }

    @Override
    public void feed() {
    }

    @Override
    public String getInfo() {
        return null;
    }

    @Override
    public Collection<Fish> getFish() {
        return this.fish;
    }

    @Override
    public Collection<Decoration> getDecorations() {
        return this.decorations;
    }
}
